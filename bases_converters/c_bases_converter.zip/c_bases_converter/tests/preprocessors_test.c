#include "header.h"

int main(int argc, char const *argv[])
{

    string str = "2ABCD";
    int ascii_to_int = ascii_char_to_int(str[0], true);
    printf("%c --> %d \n", str[0], ascii_to_int);
    printf("\nAll is good");

    return 0;
}
